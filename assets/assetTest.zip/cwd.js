console.log('Hello World!');
let cwd = process.cwd();
console.log("current working directory: ", cwd);

